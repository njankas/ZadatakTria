import React, {Component} from 'react';
import Review from './review';
import { BrowserRouter as Router,Route } from 'react-router-dom';
import {Link} from 'react-router-dom';

class Products extends Component{

  render(){
  
    return (
      <Router>
      <div>
       
          <Route exact path="/" render={props=>(
        
            <React.Fragment>
                   <h1 style={{paddingLeft:'40px'}}>New Products</h1>
              <ul>
              {
                this.props.products.map(function(item){
                  return(
                  <div key={item.id} style={{border:'1px solid black', padding:'5px', marginRight:'55%'}}>
                  <Link to={{pathname:`/${item.name}`, state:{item}}}>{item.name}</Link>
                  <p>Price: {item.price} kn</p>
                  <p>Short description: {item.short_description}</p>      
                  </div>                  
                  )
                  })
              }       
              
              </ul>
             </React.Fragment>
            )}/>
              <Route path="/:name" component={Review}/>
        </div>  
</Router>
    );
  }
}

export default Products;