import React, {Component} from 'react';


export class AddComment extends Component{

    constructor(props){
        super(props);
        this.state={  
            id: this.props.id,        
            review: ''
        }      
    }


    change = (e) =>this.setState({review:e.target.value});    

    submit = (e) =>{  
      e.preventDefault();
        const data = {
            review: this.state.review,
            id: this.state.id
        }
     fetch('http://localhost:9000/testAPI/',{
         method:'POST',
         body: JSON.stringify(data),
         headers: {'Content-Type': 'application/json',
                    'Accept': 'application/json'}
     }).then(res=>res.json()).catch(error=>console.error('Error',error)).then(
         response=> console.log('Poslano',response))
         document.getElementById("forma").reset(); 
    }

render(){

return(
<form id='forma' onSubmit={this.submit}>
<h4>Leave a Review</h4>
 <textarea type='text' rows='20' cols='100' onChange={this.change}/><br/>
 <input type='submit' value='Submit' />
</form>
)

}
}

export default AddComment;