import React, {Component} from 'react';
import Comment from './AddComment';
class Review extends Component{
    constructor(props){
        super(props);
        this.state={
            product: this.props.location.state.item,
       
        }
    }
  
render(){
   return(
        <React.Fragment>
            <div>
                <ul>
                                                                        
                   <h2>{this.state.product.name}</h2>
                   <p>Price: {this.state.product.price}  kn</p>       
                   <p style={{marginRight:'55%'}}>Long description: {this.state.product.long_description} </p>        
                   
                    <Comment id={this.state.product.id}/>
                </ul>
                </div>
                </React.Fragment>
    )       
   }
}



export default Review;