import React from 'react';
import Products from './products';

class App extends React.Component{
  constructor(){
    super();
    this.state={
    products : []
    };
  }
  
  componentDidMount(){
    fetch('http://localhost:9000/testAPI')
    .then(res=> res.json())
    .then(res => {
      this.setState({
        products: res
      })
    });
  }
 
render(){

  return (
    <div className="App">
      <Products products={this.state.products}/>
  </div>
  );
}
}
export default App;
