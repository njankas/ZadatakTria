var express = require('express');
var router = express.Router();
var mysql =  require('mysql');

var connection = mysql.createConnection({
    host:'localhost',
    user: 'root',
    password:'',
    database: 'company'
});

router.get('/',function(req,resp){
    connection.query("select * from products", function(error,rows,fields){
    if(!!error){
        console.log('Error u upitu');
    }else{
        
        resp.json(rows);
    }
})
});

router.post('/', function(req, res) {
    var review = req.body.review;
    var id = req.body.id;
        connection.query("insert into customerreviews(review,id_product) values('"+review+"','"+id+"')", function (error, results, fields) {
        if(error) throw error;
        res.send(review);
    })
});


connection.connect(function(error){
if(!!error){
    console.log('Error');
}else{
    console.log('Connected');
}
});

module.exports=router;